package com.mycompany.applicationone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
